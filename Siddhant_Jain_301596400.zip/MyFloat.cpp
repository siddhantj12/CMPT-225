#include "MyFloat.h"
#include <string> 
#include <algorithm>
#include <stdexcept> 
#include <cctype>   

// Default constructor
MyFloat::MyFloat() {
    integerLen = 1;
    integer = new short[1];
    integer[0] = 0;

    fractionalLen = 1;
    fractional = new short[fractionalLen];
    fractional[0] = 0;

}

// Constructor from string
MyFloat::MyFloat(const std::string& input) {
    if (!isValidNumber(input)) {
        throw std::invalid_argument("MyFloat: invalid input string \"" + input + "\"");
    }

// Find decimal point
    size_t dotPos = input.find('.');

    std::string intPart;
    std::string fracPart;

    if (dotPos == std::string::npos) {
        intPart = input;
        fracPart = "0";
    } else {
        intPart = input.substr(0, dotPos);
        fracPart = input.substr(dotPos + 1);

        if (intPart.empty()) {
            intPart = "0";
        }
        if (fracPart.empty()) {
            fracPart = "0";
        }
    }

    integerLen  = static_cast<int>(intPart.size());
    integer     = new short[integerLen];
    for (int i = 0; i < integerLen; ++i) {
        integer[i] = static_cast<short>(intPart[i] - '0');
    }

    fractionalLen  = static_cast<int>(fracPart.size());
    fractional     = new short[fractionalLen];
    for (int i = 0; i < fractionalLen; ++i) {
        fractional[i] = static_cast<short>( fracPart[i] - '0');
    }
}

MyFloat& MyFloat::operator=(const MyFloat& other) {
    if (this == &other) {
        // self‐assignment ⇒ do nothing
        return *this;
    }

    // 4.1) Delete our existing arrays
    delete[] integer;
    delete[] fractional;

    integerLen = other.integerLen;
    integer    = new short[integerLen];
    for (int i = 0; i < integerLen; ++i) {
        integer[i] = other.integer[i];
    }

    // 4.3) Deep-copy the fractional part
    fractionalLen = other.fractionalLen;
    fractional    = new short[fractionalLen];
    for (int i = 0; i < fractionalLen; ++i) {
        fractional[i] = other.fractional[i];
    }
    return *this;
}

    


MyFloat::~MyFloat() {
    delete[] integer;
    delete[] fractional;
}
// BIG 3 NEEDED

// Comparison operators
bool MyFloat::operator==(const MyFloat& other) const {
   if (integerLen != other.integerLen) return false;
   if (fractionalLen != other.fractionalLen) return false;

   // Compare int digits
   for  (int i = 0; i <integerLen; ++i) {
        if (integer[i] != other.integer[i]) {
            return false;
        }
   }

    for (int i = 0; i < fractionalLen; ++i) {
        if (fractional[i] != other.fractional[i]) {
        return false;
        }
    }
    return true;
}

bool MyFloat::operator!=(const MyFloat& other) const {
    return !(*this == other);
}

MyFloat MyFloat::operator+(const MyFloat& other) const {
    int maxFracLen = std::max(fractionalLen, other.fractionalLen);
    short* resultFrac = new short[maxFracLen];
    int carry = 0;

    for (int offset = 0; offset < maxFracLen; ++offset) {
        int idxA = fractionalLen - 1 - offset;
        int idxB = other.fractionalLen - 1 - offset;

        int digitA = (idxA >= 0 ? fractional[idxA] : 0);
        int digitB = (idxB >= 0 ? other.fractional[idxB] : 0);

        int sum = digitA + digitB + carry;
        resultFrac[maxFracLen - 1 - offset] = static_cast<short>(sum % 10);
        carry = sum / 10;
    }

    int maxIntLen = std::max(integerLen, other.integerLen);
    short* tempInt = new short[maxIntLen];

    for (int offset = 0; offset < maxIntLen; ++offset) {
        int idxA = integerLen - 1 - offset;
        int idxB = other.integerLen - 1 - offset;

        int digitA = (idxA >= 0 ? integer[idxA] : 0);
        int digitB = (idxB >= 0 ? other.integer[idxB] : 0);

        int sum = digitA + digitB + carry;
        tempInt[maxIntLen - 1 - offset] = static_cast<short>(sum % 10);
        carry = sum / 10;
    }

    short* resultInt;
    int resultIntLen;
    if (carry > 0) {
        resultIntLen = maxIntLen + 1;
        resultInt = new short[resultIntLen];
        resultInt[0] = static_cast<short>(carry);

        for (int i = 0; i <maxIntLen; ++i) {
            resultInt[i + 1] = tempInt[i];
        }
        delete[] tempInt;
    } else {
        resultIntLen = maxIntLen;
        resultInt = tempInt;
    }

    MyFloat sumObj;
    delete[] sumObj.integer;
    delete[] sumObj.fractional;

    sumObj.integerLen       = resultIntLen;
    sumObj.integer          = resultInt;
    sumObj.fractionalLen    = maxFracLen;
    sumObj.fractional       = resultFrac;

    return sumObj;
}

// friend operator<< and operator>>
std::ostream& operator<<(std::ostream& os, const MyFloat& f) {
    for(int i = 0; i < f.integerLen; i++){
        os << f.integer[i];
    }
    os << '.';
    for(int i = 0; i < f.fractionalLen; i++){
        os << f.fractional[i];
    }
    return os;
}

std::istream& operator>>(std::istream& is, MyFloat& f) {
    std::string input;
    is >> input;

     if (!f.isValidNumber(input)) {
        is.setstate(std::ios::failbit);
        return is;
    }
    MyFloat temp(input);
    f = temp;
    return is;

    return is;
}

bool MyFloat::isValidNumber(const std::string& str) const {
    if (str.empty()) return false;

    int i = 0;

    bool hasDigitsBeforeDot = false;
    int len = str.length();
    while (i < len && std::isdigit(str[i])) {
        hasDigitsBeforeDot = true;
        i++;
    }

    // Optional decimal part
    if (i < len && str[i] == '.') {
        i++;
        bool hasDigitsAfterDot = false;
        while (i < len && std::isdigit(str[i])) {
            hasDigitsAfterDot = true;
            i++;
        }
        if (!hasDigitsBeforeDot && !hasDigitsAfterDot)
            return false; // e.g., "." with no digits
    }

    return i == len;
}


