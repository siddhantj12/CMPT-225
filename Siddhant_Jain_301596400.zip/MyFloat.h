#ifndef MYFLOAT_HPP
#define MYFLOAT_HPP

#include <string>
#include <iostream>

class MyFloat{
    public:
        // Constructors
        MyFloat();
        MyFloat(const std::string& input);

        // Big 3
        MyFloat(const MyFloat& other);
    MyFloat& operator=(const MyFloat& other);
    ~MyFloat();

    // Addition
    MyFloat operator+(const MyFloat& other) const;

    // Comparison
    bool operator==(const MyFloat& other) const;
    bool operator!=(const MyFloat& other) const;

    // I/O
    friend std::ostream& operator<<(std::ostream& os, const MyFloat& f);
    friend std::istream& operator>>(std::istream& is, MyFloat& f);

private:
    short* integer;      // pointer to an array of integer digits (most significant at index 0)
    int    integerLen;   // length of the integer array

    short* fractional;   // pointer to an array of fractional digits (first digit after '.' at index 0)
    int    fractionalLen;// length of the fractional array

    // Helper: checks that "str" is a valid “optional digits, optional ‘.’, optional digits” representation
    bool isValidNumber(const std::string& str) const;

};

#endif // MYFLOAT_HPP

   