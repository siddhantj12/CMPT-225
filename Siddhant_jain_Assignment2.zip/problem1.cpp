// CMPT 225 D100 - Summer 2025
// Instructor: Jocelyn Minns
// DO NOT REPOST
// Student name: 

#include <iostream>
#include <string>
#include <vector>
#include <optional>

using std::string;

// structure for book data
struct Book {
    string title;
    string author;
    bool isCheckedOut;
};

// Abstract class
class Library {
public:
    // virtual destructor, common practice for abstract classes
    virtual ~Library() {}; 

    // Adds a new book to the library at a specific ID (shelf spot)
    virtual bool addBook(int id, const std::string& title, const std::string& author) = 0;

    // Removes a book from the library based on its ID
    virtual bool removeBook(int id) = 0;

    // Replaces an existing book at a given ID with a new title and author
    virtual bool swapBook(int id, const std::string& newTitle, const std::string& newAuthor) = 0;

    // Flags the book at the given ID as checked out (borrowed)
    virtual bool checkOutBook(int id) = 0;

    // Flags the book at the given ID as returned (in the library)
    virtual bool returnBook(int id) = 0;

    // Checks if the book at the given ID is currently in the library
    virtual bool isInLibrary(int id) const = 0;

    // Returns a string with information about the book at the given ID
    virtual std::string getBookInfo(int id) const = 0;

    // Returns the total number of books currently stored in the library
    virtual int totalBooks() const = 0;

    // Returns the number of books that are currently available in the library
    virtual int booksInLibrary() const = 0;

    // Returns the number of books that are currently checked out
    virtual int booksLentOut() const = 0;
};


class SFULibrary : public Library{
public:
    SFULibrary()
      : shelves(500)
      , totalCount(0)
      , inLibraryCount(0)
      , lentOutCount(0)
    {}

    // addBook: if necessary, grow the shelf to fit `id`
    bool addBook(int id, const string& title, const string& author) override {
        if (id < 0) return false;
        if (id < 0 || id >= (int)shelves.size()) 
            return false;
        if (shelves[id].has_value()) 
            return false;                // slot already occupied

        shelves[id] = Book{title, author, false};
        ++totalCount;
        ++inLibraryCount;
        return true;
    }

    bool removeBook(int id) override {
        if (!validSlot(id)) return false;
        auto &opt = shelves[id];
        if (!opt.has_value()) return false;

        // adjust counters
        if (opt->isCheckedOut) --lentOutCount;
        else                    --inLibraryCount;
        --totalCount;

        opt.reset();   // now empty
        return true;
    }

    bool swapBook(int id, const string& newTitle, const string& newAuthor) override {
        if (!validSlot(id)) return false;
        auto &opt = shelves[id];
        if (!opt.has_value()) return false;

        // if it was lent out, bring it back
        if (opt->isCheckedOut) {
            opt->isCheckedOut = false;
            --lentOutCount;
            ++inLibraryCount;
        }

        opt->title  = newTitle;
        opt->author = newAuthor;
        return true;
    }

    bool checkOutBook(int id) override {
        if (!validSlot(id)) return false;
        auto &opt = shelves[id];
        if (!opt.has_value() || opt->isCheckedOut) return false;

        opt->isCheckedOut = true;
        --inLibraryCount;
        ++lentOutCount;
        return true;
    }

    bool returnBook(int id) override {
        if (!validSlot(id)) return false;
        auto &opt = shelves[id];
        if (!opt.has_value() || !opt->isCheckedOut) return false;

        opt->isCheckedOut = false;
        ++inLibraryCount;
        --lentOutCount;
        return true;
    }

    bool isInLibrary(int id) const override {
        return validSlot(id)
            && shelves[id].has_value()
            && !shelves[id]->isCheckedOut;
    }

    string getBookInfo(int id) const override {
        if (!validSlot(id) || !shelves[id].has_value())
            return "No book at ID " + std::to_string(id);

        const Book &b = *shelves[id];
        return "\"" + b.title + "\" by " + b.author
             + " — " + (b.isCheckedOut ? "Checked Out" : "In Library");
    }

    int totalBooks()     const override { return totalCount; }
    int booksInLibrary() const override { return inLibraryCount; }
    int booksLentOut()   const override { return lentOutCount; }

private:
    std::vector<std::optional<Book>> shelves;
    int totalCount, inLibraryCount, lentOutCount;

    bool validSlot(int id) const {
        return id >= 0 && id < (int)shelves.size();
    }
};


int main() {
    Library* lib = new SFULibrary();

   
    
    lib->addBook(0, "1984", "George Orwell");
    lib->addBook(1, "The Hobbit", "J.R.R. Tolkien");
    lib->addBook(2, "Dune", "Frank Herbert");
    lib->removeBook(1);
    bool ok = lib->checkOutBook(42);
    lib->addBook(10, "Neuromancer", "Gibson");


    std::cout << "Checking out non-existent ID 42 → " << (ok ? "true" : "false") << "\n";
    std::cout << lib->getBookInfo(0) << "\n";
    lib->checkOutBook(0);
    std::cout << lib->getBookInfo(0) << "\n";

    lib->returnBook(0);
    std::cout << lib->getBookInfo(0) << "\n";

    lib->swapBook(2, "Foundation", "Isaac Asimov");
    std::cout << lib->getBookInfo(2) << "\n";
    std::cout << lib->getBookInfo(10) << "\n";
    std::cout << "Total books: " << lib->totalBooks() << "\n";
    std::cout << "Books in: " << lib->booksInLibrary() << "\n";
    std::cout << "Books out: " << lib->booksLentOut() << "\n";
    std::cout << "After removing ID 1, total = "
          << lib->totalBooks() << ", in = "
          << lib->booksInLibrary() << ", out = "
          << lib->booksLentOut() << "\n";
    delete lib;
    return 0;
}

