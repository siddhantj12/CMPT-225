#include <string>
#include <iostream>
#include<chrono>
#include<stdexcept>

class SinglyLinkedList {
private:
    struct Node {
        std::string data;
        Node* next;
    };

    Node* head;
    int size;
     
     // Helper for recursive reversal
    Node* reverseRecursiveUtil(Node* node) {
        if (!node || !node->next) {
            return node;
        }
        Node* newHead = reverseRecursiveUtil(node->next);
        node->next->next = node;
        node->next = nullptr;
        return newHead;
    }

public:
    SinglyLinkedList();
    ~SinglyLinkedList();

    void insertFront(const std::string& value);
    bool isEmpty() const;
    int getSize() const;
    void printList() const;

    // Big Three
    SinglyLinkedList(const SinglyLinkedList& other);
    SinglyLinkedList& operator=(const SinglyLinkedList& other);
    void clear(Node* node);
    void reverseIterative();
    void reverseRecursive();
};


// Constructor
SinglyLinkedList::SinglyLinkedList() : head(nullptr), size(0) {}

// Destructor
SinglyLinkedList::~SinglyLinkedList() {
    clear(head);
}

// Insert at front
void SinglyLinkedList::insertFront(const std::string& value) {
    Node* newNode = new Node;
    newNode->data = value;
    newNode->next = head;
    head = newNode;
    size++;
}

// Is empty
bool SinglyLinkedList::isEmpty() const {
    return head == nullptr;
}

// Get size
int SinglyLinkedList::getSize() const {
    return size;
}

// Print list
void SinglyLinkedList::printList() const {
    Node* current = head;
    while (current) {
        std::cout << current->data << " -> ";
        current = current->next;
    }
    std::cout << "nullptr\n";
}

// Copy constructor
SinglyLinkedList::SinglyLinkedList(const SinglyLinkedList& other) : head(nullptr), size(0) {
    Node* current = other.head;
    Node** tail = &head;
    while (current) {
        *tail = new Node;
        (*tail)->data = current->data;
        (*tail)->next = nullptr;
        tail = &((*tail)->next);
        current = current->next;
        size++;
    }
}

// Assignment operator
SinglyLinkedList& SinglyLinkedList::operator=(const SinglyLinkedList& other) {
    if (this != &other) {
        clear(head);
        Node* current = other.head;
        Node** tail = &head;
        while (current) {
            *tail = new Node;
            (*tail)->data = current->data;
            (*tail)->next = nullptr;
            tail = &((*tail)->next);
            current = current->next;
            size++;
        }
    }
    return *this;
}

// Clear list
void SinglyLinkedList::clear(Node* node) {
    if (node == nullptr) return;
    clear(node->next);
    delete node;
}
    // Iterative reversal
void SinglyLinkedList::reverseIterative() {
    if (isEmpty())
        throw std::runtime_error("Cannot reverse an empty list (iterative)");
    Node* prev = nullptr;
    Node* curr = head;
    while (curr) {
        Node* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    head = prev;
}

// Recursive reversal
void SinglyLinkedList::reverseRecursive() {
    if (isEmpty())
        throw std::runtime_error("Cannot reverse an empty list (recursive)");
    head = reverseRecursiveUtil(head);
}

int main() {
    SinglyLinkedList list;
    list.insertFront("Banana");
    list.insertFront("Apple");
    list.insertFront("Orange");

    std::cout << "Original list: ";
    list.printList(); // Orange -> Apple -> Banana -> nullptr

    // Demonstrate iterative reversal
    list.reverseIterative();
    std::cout << "After iterative reverse: ";
    list.printList();

    // Demonstrate recursive reversal
    list.reverseRecursive();
    std::cout << "After recursive reverse: ";
    list.printList();

    // Performance timing
    const int N = 100000;
    SinglyLinkedList list1, list2;
    for (int i = 0; i < N; ++i) {
        list1.insertFront("Node");
        list2.insertFront("Node");
    }

    auto t1 = std::chrono::high_resolution_clock::now();
    list1.reverseIterative();
    auto t2 = std::chrono::high_resolution_clock::now();
    auto durationIter = std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();

    auto t3 = std::chrono::high_resolution_clock::now();
    list2.reverseRecursive();
    auto t4 = std::chrono::high_resolution_clock::now();
    auto durationRec = std::chrono::duration_cast<std::chrono::microseconds>(t4 - t3).count();

    std::cout << "Iterative reversal time: " << durationIter << " microseconds\n";
    std::cout << "Recursive reversal time: " << durationRec << " microseconds\n";

    return 0;
}